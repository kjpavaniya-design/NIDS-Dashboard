"""
engine/dataset_generator.py
────────────────────────────
Generates a realistic synthetic network-flow dataset modelled after NSL-KDD.
Each record represents one network connection/flow with 23 features.

Attack categories modelled:
  DoS        — Denial of Service (SYN flood, UDP flood, ICMP flood)
  Probe      — Port scan, OS fingerprint, service enumeration
  R2L        — Remote-to-Local (brute force SSH/FTP/HTTP auth)
  U2R        — User-to-Root (privilege escalation, buffer overflow)
  Normal     — Legitimate traffic (HTTP, DNS, SMTP, FTP, SSH)
"""

import random
import math
import time
import datetime
import ipaddress

# ── Known malicious IP blocks (simulated threat-intel feed) ─────────────────
BLACKLISTED_IPS = [
    "185.220.101.", "45.142.212.", "193.32.162.", "79.124.49.",
    "198.199.77.",  "91.108.4.",   "10.99.99.",   "172.16.99.",
]

INTERNAL_NETS  = ["192.168.1.", "192.168.2.", "10.0.0.", "172.16.1."]
EXTERNAL_HOSTS = [f"{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}"
                  for _ in range(80)]

PROTOCOLS = ["tcp", "udp", "icmp"]
SERVICES  = ["http","https","ftp","ssh","dns","smtp","pop3","imap",
             "telnet","rdp","mysql","mssql","vnc","snmp","ntp","other"]
FLAGS     = ["SF","S0","REJ","RSTO","SH","S1","S2","S3","OTH","RSTOS0"]

# ── Feature means/stds per traffic class ─────────────────────────────────────
# Format: (mean, std) for each numeric feature
PROFILES = {
    # ── Normal traffic ─────────────────────────────────────────────────────
    "normal": {
        "duration":         (8.5,   12.0),
        "src_bytes":        (2800,  4500),
        "dst_bytes":        (3200,  5000),
        "land":             (0,     0),      # binary: src==dst?
        "wrong_fragment":   (0.01,  0.1),
        "urgent":           (0,     0),
        "hot":              (1.2,   2.0),
        "num_failed_logins":(0.02,  0.15),
        "logged_in":        (0.85,  0),      # probability
        "num_compromised":  (0.1,   0.5),
        "count":            (120,   80),
        "srv_count":        (28,    18),
        "serror_rate":      (0.02,  0.04),
        "rerror_rate":      (0.01,  0.03),
        "same_srv_rate":    (0.92,  0.08),
        "diff_srv_rate":    (0.05,  0.04),
        "dst_host_count":   (160,   60),
        "dst_host_srv_count":(80,   30),
        "dst_host_diff_srv_rate": (0.05, 0.04),
        "dst_host_serror_rate":   (0.02, 0.04),
        "protocol": "tcp",
        "flag_dist": {"SF": 0.88, "S1": 0.05, "RSTO": 0.04, "OTH": 0.03},
    },
    # ── DoS — SYN flood ─────────────────────────────────────────────────────
    "dos_syn": {
        "duration":         (0.0,   0.2),
        "src_bytes":        (40,    20),
        "dst_bytes":        (0,     5),
        "land":             (0,     0),
        "wrong_fragment":   (0,     0),
        "urgent":           (0,     0),
        "hot":              (0,     0),
        "num_failed_logins":(0,     0),
        "logged_in":        (0,     0),
        "num_compromised":  (0,     0),
        "count":            (490,   20),
        "srv_count":        (490,   20),
        "serror_rate":      (0.97,  0.03),
        "rerror_rate":      (0.0,   0.01),
        "same_srv_rate":    (0.99,  0.01),
        "diff_srv_rate":    (0.01,  0.01),
        "dst_host_count":   (255,   1),
        "dst_host_srv_count":(255,  1),
        "dst_host_diff_srv_rate": (0.0,  0.01),
        "dst_host_serror_rate":   (0.97, 0.03),
        "protocol": "tcp",
        "flag_dist": {"S0": 0.95, "S1": 0.03, "SF": 0.02},
    },
    # ── DoS — UDP flood ─────────────────────────────────────────────────────
    "dos_udp": {
        "duration":         (0.0,   0.1),
        "src_bytes":        (64,    8),
        "dst_bytes":        (0,     0),
        "land":             (0,     0),
        "wrong_fragment":   (0.5,   0.4),
        "urgent":           (0,     0),
        "hot":              (0,     0),
        "num_failed_logins":(0,     0),
        "logged_in":        (0,     0),
        "num_compromised":  (0,     0),
        "count":            (480,   30),
        "srv_count":        (480,   30),
        "serror_rate":      (0.0,   0.01),
        "rerror_rate":      (0.98,  0.02),
        "same_srv_rate":    (0.98,  0.02),
        "diff_srv_rate":    (0.01,  0.01),
        "dst_host_count":   (255,   1),
        "dst_host_srv_count":(255,  1),
        "dst_host_diff_srv_rate": (0.0,  0.0),
        "dst_host_serror_rate":   (0.0,  0.01),
        "protocol": "udp",
        "flag_dist": {"S0": 0.6, "OTH": 0.4},
    },
    # ── Probe — port scan ────────────────────────────────────────────────────
    "probe_scan": {
        "duration":         (0.05,  0.2),
        "src_bytes":        (52,    30),
        "dst_bytes":        (0,     10),
        "land":             (0,     0),
        "wrong_fragment":   (0,     0),
        "urgent":           (0,     0),
        "hot":              (0.1,   0.3),
        "num_failed_logins":(0,     0),
        "logged_in":        (0,     0),
        "num_compromised":  (0,     0),
        "count":            (30,    20),
        "srv_count":        (10,    8),
        "serror_rate":      (0.1,   0.1),
        "rerror_rate":      (0.6,   0.2),
        "same_srv_rate":    (0.1,   0.1),
        "diff_srv_rate":    (0.85,  0.1),
        "dst_host_count":   (30,    20),
        "dst_host_srv_count":(5,    5),
        "dst_host_diff_srv_rate": (0.85, 0.1),
        "dst_host_serror_rate":   (0.1,  0.1),
        "protocol": "tcp",
        "flag_dist": {"REJ": 0.5, "RSTO": 0.2, "S0": 0.2, "SF": 0.1},
    },
    # ── R2L — brute-force SSH ────────────────────────────────────────────────
    "r2l_brute": {
        "duration":         (3.0,   2.0),
        "src_bytes":        (350,   100),
        "dst_bytes":        (280,   80),
        "land":             (0,     0),
        "wrong_fragment":   (0,     0),
        "urgent":           (0,     0),
        "hot":              (0.2,   0.5),
        "num_failed_logins":(4.5,   2.0),
        "logged_in":        (0.05,  0),
        "num_compromised":  (0,     0),
        "count":            (60,    30),
        "srv_count":        (60,    30),
        "serror_rate":      (0.0,   0.01),
        "rerror_rate":      (0.0,   0.01),
        "same_srv_rate":    (0.98,  0.02),
        "diff_srv_rate":    (0.02,  0.02),
        "dst_host_count":   (80,    40),
        "dst_host_srv_count":(80,   40),
        "dst_host_diff_srv_rate": (0.02, 0.02),
        "dst_host_serror_rate":   (0.0,  0.01),
        "protocol": "tcp",
        "flag_dist": {"SF": 0.6, "RSTO": 0.3, "REJ": 0.1},
    },
    # ── U2R — buffer overflow ────────────────────────────────────────────────
    "u2r_overflow": {
        "duration":         (0.5,   1.0),
        "src_bytes":        (1800,  800),
        "dst_bytes":        (520,   200),
        "land":             (0,     0),
        "wrong_fragment":   (0.3,   0.4),
        "urgent":           (0.4,   0.5),
        "hot":              (8.0,   4.0),
        "num_failed_logins":(0.1,   0.3),
        "logged_in":        (0.3,   0),
        "num_compromised":  (4.5,   3.0),
        "count":            (8,     6),
        "srv_count":        (4,     3),
        "serror_rate":      (0.05,  0.05),
        "rerror_rate":      (0.05,  0.05),
        "same_srv_rate":    (0.5,   0.3),
        "diff_srv_rate":    (0.3,   0.2),
        "dst_host_count":   (20,    15),
        "dst_host_srv_count":(10,   8),
        "dst_host_diff_srv_rate": (0.3,  0.2),
        "dst_host_serror_rate":   (0.05, 0.05),
        "protocol": "tcp",
        "flag_dist": {"SF": 0.5, "S1": 0.2, "RSTO": 0.2, "OTH": 0.1},
    },
}

# ── Service / port mapping ────────────────────────────────────────────────────
ATTACK_SERVICES = {
    "dos_syn":      ["http", "https", "smtp", "ftp", "ssh"],
    "dos_udp":      ["dns", "snmp", "ntp", "other"],
    "probe_scan":   ["http", "ftp", "ssh", "telnet", "rdp", "mysql", "mssql", "other"],
    "r2l_brute":    ["ssh", "ftp", "telnet", "rdp"],
    "u2r_overflow": ["http", "ftp", "smtp", "other"],
    "normal":       ["http", "https", "dns", "smtp", "ftp", "ssh", "other"],
}

ATTACK_PORTS = {
    "http": 80, "https": 443, "ftp": 21, "ssh": 22, "dns": 53,
    "smtp": 25, "pop3": 110, "imap": 143, "telnet": 23, "rdp": 3389,
    "mysql": 3306, "mssql": 1433, "vnc": 5900, "snmp": 161,
    "ntp": 123, "other": random.randint(1024, 65535),
}

ATTACK_LABELS = {
    "normal":       "Normal",
    "dos_syn":      "DoS",
    "dos_udp":      "DoS",
    "probe_scan":   "Probe",
    "r2l_brute":    "R2L",
    "u2r_overflow": "U2R",
}

ATTACK_SUBTYPES = {
    "normal":       "Normal",
    "dos_syn":      "SYN Flood",
    "dos_udp":      "UDP Flood",
    "probe_scan":   "Port Scan",
    "r2l_brute":    "SSH Brute Force",
    "u2r_overflow": "Buffer Overflow",
}

SEVERITY_MAP = {
    "Normal":  "info",
    "DoS":     "high",
    "Probe":   "medium",
    "R2L":     "high",
    "U2R":     "critical",
}

THREAT_SCORE_MAP = {
    "Normal":  (0,  15),
    "Probe":   (35, 55),
    "DoS":     (60, 85),
    "R2L":     (55, 80),
    "U2R":     (80, 99),
}


def _clamp(val, lo, hi):
    return max(lo, min(hi, val))


def _gauss(mean, std):
    if std == 0:
        return mean
    return random.gauss(mean, std)


def _weighted_choice(d):
    keys, weights = zip(*d.items())
    r = random.random()
    cum = 0
    for k, w in zip(keys, weights):
        cum += w
        if r <= cum:
            return k
    return keys[-1]


def _src_ip(attack_type):
    """Return a source IP — attackers use external or blacklisted ranges."""
    if attack_type == "normal":
        base = random.choice(INTERNAL_NETS)
        return base + str(random.randint(2, 254))
    if random.random() < 0.35:
        base = random.choice(BLACKLISTED_IPS)
        return base + str(random.randint(1, 254))
    if random.random() < 0.5:
        return random.choice(EXTERNAL_HOSTS)
    # Spoofed / random
    return (f"{random.randint(1,223)}.{random.randint(0,255)}"
            f".{random.randint(0,255)}.{random.randint(1,254)}")


def _dst_ip():
    base = random.choice(INTERNAL_NETS)
    return base + str(random.randint(2, 30))  # servers in small range


def generate_record(attack_type=None, timestamp=None):
    """
    Generate one synthetic network-flow record.
    Returns a dict with all features + metadata.
    """
    if attack_type is None:
        # Weighted: ~70% normal, rest attacks
        choices = ["normal"]*70 + ["dos_syn"]*8 + ["dos_udp"]*6 + \
                  ["probe_scan"]*8 + ["r2l_brute"]*5 + ["u2r_overflow"]*3
        attack_type = random.choice(choices)

    p = PROFILES[attack_type]

    if timestamp is None:
        timestamp = datetime.datetime.now()

    service  = random.choice(ATTACK_SERVICES[attack_type])
    dst_port = ATTACK_PORTS.get(service, random.randint(1024, 65535))
    src_port = random.randint(1024, 65535)
    protocol = p["protocol"]
    flag     = _weighted_choice(p["flag_dist"])

    src_ip = _src_ip(attack_type)
    dst_ip = _dst_ip()

    # Numeric features
    def g(key):
        return _gauss(p[key][0], p[key][1])

    duration         = max(0.0, round(g("duration"), 3))
    src_bytes        = max(0, int(g("src_bytes")))
    dst_bytes        = max(0, int(g("dst_bytes")))
    land             = 1 if (src_ip == dst_ip) else 0
    wrong_fragment   = max(0, int(g("wrong_fragment")))
    urgent           = max(0, int(g("urgent")))
    hot              = max(0, int(abs(g("hot"))))
    num_failed_logins = max(0, int(abs(g("num_failed_logins"))))
    logged_in        = 1 if random.random() < p["logged_in"][0] else 0
    num_compromised  = max(0, int(abs(g("num_compromised"))))
    count            = _clamp(int(abs(g("count"))), 1, 511)
    srv_count        = _clamp(int(abs(g("srv_count"))), 1, 511)
    serror_rate      = round(_clamp(g("serror_rate"), 0, 1), 2)
    rerror_rate      = round(_clamp(g("rerror_rate"), 0, 1), 2)
    same_srv_rate    = round(_clamp(g("same_srv_rate"), 0, 1), 2)
    diff_srv_rate    = round(_clamp(g("diff_srv_rate"), 0, 1), 2)
    dst_host_count   = _clamp(int(abs(g("dst_host_count"))), 1, 255)
    dst_host_srv_count = _clamp(int(abs(g("dst_host_srv_count"))), 1, 255)
    dst_host_diff_srv_rate = round(_clamp(g("dst_host_diff_srv_rate"), 0, 1), 2)
    dst_host_serror_rate   = round(_clamp(g("dst_host_serror_rate"), 0, 1), 2)

    label    = ATTACK_LABELS[attack_type]
    subtype  = ATTACK_SUBTYPES[attack_type]
    severity = SEVERITY_MAP[label]
    lo, hi   = THREAT_SCORE_MAP[label]
    threat_score = random.randint(lo, hi)

    # Is the source IP blacklisted?
    blacklisted = any(src_ip.startswith(b) for b in BLACKLISTED_IPS)

    return {
        # ── Identifiers ──
        "timestamp":      timestamp.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
        "src_ip":         src_ip,
        "dst_ip":         dst_ip,
        "src_port":       src_port,
        "dst_port":       dst_port,
        "protocol":       protocol,
        "service":        service,
        "flag":           flag,
        # ── Flow features ──
        "duration":       duration,
        "src_bytes":      src_bytes,
        "dst_bytes":      dst_bytes,
        "land":           land,
        "wrong_fragment": wrong_fragment,
        "urgent":         urgent,
        "hot":            hot,
        "num_failed_logins": num_failed_logins,
        "logged_in":      logged_in,
        "num_compromised": num_compromised,
        # ── Traffic stats ──
        "count":          count,
        "srv_count":      srv_count,
        "serror_rate":    serror_rate,
        "rerror_rate":    rerror_rate,
        "same_srv_rate":  same_srv_rate,
        "diff_srv_rate":  diff_srv_rate,
        "dst_host_count": dst_host_count,
        "dst_host_srv_count": dst_host_srv_count,
        "dst_host_diff_srv_rate": dst_host_diff_srv_rate,
        "dst_host_serror_rate":   dst_host_serror_rate,
        # ── Labels ──
        "attack_type":    attack_type,
        "label":          label,
        "subtype":        subtype,
        "severity":       severity,
        "threat_score":   threat_score,
        "blacklisted_src": blacklisted,
    }


def generate_batch(n=50, burst_attack=None):
    """Generate a batch of n records, optionally with a burst of a specific attack."""
    records = []
    now = datetime.datetime.now()
    for i in range(n):
        ts = now - datetime.timedelta(seconds=(n - i) * 0.2)
        if burst_attack and random.random() < 0.7:
            records.append(generate_record(burst_attack, ts))
        else:
            records.append(generate_record(timestamp=ts))
    return records


def generate_historical(hours=2, records_per_minute=12):
    """Generate historical data for the last `hours` hours."""
    records = []
    now = datetime.datetime.now()
    total_minutes = hours * 60
    for m in range(total_minutes, 0, -1):
        ts_base = now - datetime.timedelta(minutes=m)
        # Inject attack bursts at realistic times
        burst = None
        if 15 <= m <= 20:
            burst = "dos_syn"
        elif 40 <= m <= 43:
            burst = "probe_scan"
        elif 70 <= m <= 72:
            burst = "r2l_brute"
        elif 95 <= m <= 96:
            burst = "u2r_overflow"
        n = records_per_minute + random.randint(-3, 3)
        for i in range(n):
            ts = ts_base + datetime.timedelta(seconds=random.randint(0, 59))
            if burst and random.random() < 0.65:
                records.append(generate_record(burst, ts))
            else:
                records.append(generate_record(timestamp=ts))
    return records
