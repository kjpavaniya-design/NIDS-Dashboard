"""
capture.py — Live packet capture engine using raw AF_PACKET sockets.
Captures every IPv4 packet, parses headers, assembles into flows,
and pushes events to a shared queue for the dashboard and ML engine.
"""

import socket
import struct
import threading
import time
import collections
import queue
import datetime
import random
import math

# ── Shared state ──────────────────────────────────────────────────────────────
packet_queue   = queue.Queue(maxsize=5000)   # raw parsed packets
alert_queue    = queue.Queue(maxsize=1000)   # security alerts
dataset_rows   = collections.deque(maxlen=2000)  # growing live dataset
flow_table     = {}                          # active flows keyed by 5-tuple
flow_lock      = threading.Lock()

# Live counters
stats = {
    "total_packets":   0,
    "total_bytes":     0,
    "tcp_count":       0,
    "udp_count":       0,
    "icmp_count":      0,
    "other_count":     0,
    "alerts":          0,
    "flows_active":    0,
    "flows_total":     0,
    "packets_per_sec": 0,
    "bytes_per_sec":   0,
    "start_time":      time.time(),
}

protocol_map = {6: "TCP", 17: "UDP", 1: "ICMP", 2: "IGMP", 41: "IPv6", 47: "GRE", 50: "ESP"}

# Known suspicious ports
SUSPICIOUS_PORTS = {
    23: "Telnet", 445: "SMB", 135: "RPC", 139: "NetBIOS",
    3389: "RDP", 4444: "Meterpreter", 1337: "Hacker-slang",
    6667: "IRC/Botnet", 6666: "IRC/Botnet", 31337: "BackOrifice",
    12345: "NetBus", 8080: "Alt-HTTP", 1080: "SOCKS-Proxy",
    5900: "VNC", 9090: "Alt-Web", 8443: "Alt-HTTPS",
    4899: "Radmin", 5800: "VNC-Web",
}

# Protocol threat scores
PROTO_RISK = {6: 1, 17: 1, 1: 2, 47: 5, 50: 3}

# Port scan detection: track per-source scan attempts
port_scan_tracker = collections.defaultdict(lambda: {"ports": set(), "last_seen": 0, "alerted": False})
SCAN_THRESHOLD = 15   # distinct destination ports from one source = scan
scan_lock = threading.Lock()


def parse_ethernet_frame(raw):
    """Parse raw Ethernet frame, return IP payload if IPv4."""
    if len(raw) < 14:
        return None
    eth_proto = struct.unpack("!H", raw[12:14])[0]
    if eth_proto == 0x0800:           # IPv4
        return raw[14:]
    if eth_proto == 0x86DD:           # IPv6 — skip for now
        return None
    return None


def parse_ip_header(data):
    """Parse IPv4 header. Returns dict or None."""
    if len(data) < 20:
        return None
    ver_ihl = data[0]
    version = (ver_ihl >> 4)
    ihl     = (ver_ihl & 0x0F) * 4
    if version != 4 or ihl < 20:
        return None
    tos      = data[1]
    total_len= struct.unpack("!H", data[2:4])[0]
    ttl      = data[8]
    proto    = data[9]
    src_ip   = socket.inet_ntoa(data[12:16])
    dst_ip   = socket.inet_ntoa(data[16:20])
    payload  = data[ihl:]
    return {
        "ihl": ihl, "tos": tos, "total_len": total_len,
        "ttl": ttl, "proto": proto,
        "src_ip": src_ip, "dst_ip": dst_ip,
        "payload": payload,
    }


def parse_transport(proto, payload):
    """Parse TCP/UDP/ICMP headers. Returns (sport, dport, flags, extra)."""
    if proto == 6 and len(payload) >= 20:     # TCP
        sport, dport = struct.unpack("!HH", payload[0:4])
        seq          = struct.unpack("!I", payload[4:8])[0]
        flags_byte   = payload[13]
        flags = {
            "FIN": bool(flags_byte & 0x01),
            "SYN": bool(flags_byte & 0x02),
            "RST": bool(flags_byte & 0x04),
            "PSH": bool(flags_byte & 0x08),
            "ACK": bool(flags_byte & 0x10),
            "URG": bool(flags_byte & 0x20),
        }
        win = struct.unpack("!H", payload[14:16])[0]
        return sport, dport, flags, {"seq": seq, "window": win}

    elif proto == 17 and len(payload) >= 8:   # UDP
        sport, dport, length = struct.unpack("!HHH", payload[0:6])
        return sport, dport, {}, {"udp_len": length}

    elif proto == 1 and len(payload) >= 4:    # ICMP
        icmp_type = payload[0]
        icmp_code = payload[1]
        return 0, 0, {}, {"icmp_type": icmp_type, "icmp_code": icmp_code}

    return 0, 0, {}, {}


def make_flow_key(src_ip, dst_ip, sport, dport, proto):
    """Bidirectional flow key."""
    if (src_ip, sport) < (dst_ip, dport):
        return (src_ip, dst_ip, sport, dport, proto)
    return (dst_ip, src_ip, dport, sport, proto)


def update_flow(pkt):
    """Update or create flow entry, return completed flow if finished."""
    key = make_flow_key(pkt["src_ip"], pkt["dst_ip"], pkt["sport"], pkt["dport"], pkt["proto"])
    now = pkt["timestamp"]
    completed = None

    with flow_lock:
        if key not in flow_table:
            flow_table[key] = {
                "key": key,
                "src_ip": pkt["src_ip"], "dst_ip": pkt["dst_ip"],
                "sport": pkt["sport"],   "dport": pkt["dport"],
                "proto": pkt["proto"],   "proto_name": pkt["proto_name"],
                "start_time": now,       "last_time": now,
                "packets": 0,            "bytes": 0,
                "flags_seen": set(),
                "syn_count": 0,          "rst_count": 0,
                "fin_count": 0,          "psh_count": 0,
            }
            stats["flows_total"] += 1

        f = flow_table[key]
        f["packets"] += 1
        f["bytes"]   += pkt["size"]
        f["last_time"] = now

        flags = pkt.get("flags", {})
        if flags.get("SYN"): f["syn_count"] += 1
        if flags.get("RST"): f["rst_count"] += 1
        if flags.get("FIN"): f["fin_count"] += 1
        if flags.get("PSH"): f["psh_count"] += 1
        for k, v in flags.items():
            if v: f["flags_seen"].add(k)

        # Close flow on RST/FIN or timeout
        duration = now - f["start_time"]
        if flags.get("RST") or flags.get("FIN") or duration > 120:
            completed = dict(f)
            completed["flags_seen"] = list(completed["flags_seen"])
            completed["duration"]   = duration
            del flow_table[key]

        stats["flows_active"] = len(flow_table)

    return completed


def detect_threats(pkt, flow=None):
    """
    Rule-based + heuristic threat detection.
    Returns list of alert dicts (may be empty).
    """
    alerts = []
    now    = pkt["timestamp"]
    src    = pkt["src_ip"]
    dst    = pkt["dst_ip"]
    dport  = pkt["dport"]
    sport  = pkt["sport"]
    proto  = pkt["proto"]
    flags  = pkt.get("flags", {})
    extra  = pkt.get("extra", {})

    def alert(name, severity, description, category, evidence):
        return {
            "id":          f"{int(now*1000)}-{random.randint(100,999)}",
            "timestamp":   datetime.datetime.fromtimestamp(now).strftime("%H:%M:%S.%f")[:-3],
            "name":        name,
            "severity":    severity,   # CRITICAL / HIGH / MEDIUM / LOW / INFO
            "description": description,
            "category":    category,
            "src_ip":      src,
            "dst_ip":      dst,
            "sport":       sport,
            "dport":       dport,
            "proto":       pkt["proto_name"],
            "evidence":    evidence,
            "where_checked": f"Packet header parser → Rule engine → {name}",
        }

    # ── Rule 1: SYN flood detection ────────────────────────────────────────
    if proto == 6 and flags.get("SYN") and not flags.get("ACK"):
        if flow and flow.get("syn_count", 0) > 50:
            alerts.append(alert(
                "SYN Flood", "CRITICAL",
                f"SYN flood detected from {src}: {flow['syn_count']} SYN packets in {flow.get('duration',0):.1f}s with no ACK response.",
                "DoS/DDoS",
                f"SYN_count={flow['syn_count']}, no_ACK=True, duration={flow.get('duration',0):.1f}s"
            ))

    # ── Rule 2: Port scan detection ────────────────────────────────────────
    if proto == 6 and dport > 0:
        with scan_lock:
            tracker = port_scan_tracker[src]
            tracker["ports"].add(dport)
            tracker["last_seen"] = now
            if len(tracker["ports"]) >= SCAN_THRESHOLD and not tracker["alerted"]:
                tracker["alerted"] = True
                alerts.append(alert(
                    "Port Scan", "HIGH",
                    f"Port scan from {src}: {len(tracker['ports'])} distinct ports probed (TCP).",
                    "Reconnaissance",
                    f"ports_probed={sorted(list(tracker['ports']))[:10]}..., total={len(tracker['ports'])}"
                ))

    # ── Rule 3: Suspicious destination port ───────────────────────────────
    if dport in SUSPICIOUS_PORTS:
        svc = SUSPICIOUS_PORTS[dport]
        alerts.append(alert(
            f"Suspicious Port: {svc}", "MEDIUM",
            f"Traffic to port {dport} ({svc}) from {src}. Commonly exploited or associated with malware.",
            "Suspicious Activity",
            f"dst_port={dport}, service={svc}, proto={pkt['proto_name']}"
        ))

    # ── Rule 4: ICMP flood / large ICMP ──────────────────────────────────
    if proto == 1:
        icmp_type = extra.get("icmp_type", -1)
        size = pkt["size"]
        if size > 1000:
            alerts.append(alert(
                "Large ICMP Packet", "MEDIUM",
                f"Oversized ICMP packet ({size} bytes) — possible ICMP tunnel or DoS.",
                "DoS/Tunnel",
                f"icmp_type={icmp_type}, size={size}"
            ))
        if icmp_type == 8:   # Echo request
            alerts.append(alert(
                "ICMP Echo Probe", "INFO",
                f"ICMP Echo Request from {src} to {dst}. May indicate ping sweep.",
                "Reconnaissance",
                f"icmp_type=8 (echo_request)"
            ))

    # ── Rule 5: RST injection ─────────────────────────────────────────────
    if proto == 6 and flags.get("RST") and not flow:
        alerts.append(alert(
            "TCP RST Injection", "HIGH",
            f"Unexpected TCP RST from {src} — possible connection hijacking or firewall evasion.",
            "Intrusion Attempt",
            "flags=RST, no_prior_flow=True"
        ))

    # ── Rule 6: NULL / XMAS scan ──────────────────────────────────────────
    if proto == 6:
        all_false = not any(flags.values())
        xmas = flags.get("FIN") and flags.get("URG") and flags.get("PSH")
        if all_false:
            alerts.append(alert(
                "TCP NULL Scan", "HIGH",
                f"TCP packet with NO flags set from {src} — classic NULL scan for OS fingerprinting.",
                "Reconnaissance",
                "flags=NONE (null_scan)"
            ))
        elif xmas:
            alerts.append(alert(
                "TCP XMAS Scan", "HIGH",
                f"TCP XMAS scan (FIN+URG+PSH) from {src} — used for stealth port scanning.",
                "Reconnaissance",
                "flags=FIN+URG+PSH (xmas_scan)"
            ))

    # ── Rule 7: High TTL deviation ────────────────────────────────────────
    ttl = pkt.get("ttl", 64)
    if ttl < 5:
        alerts.append(alert(
            "Low TTL Packet", "MEDIUM",
            f"Packet from {src} has TTL={ttl} — possible TTL-based firewall evasion or traceroute.",
            "Evasion",
            f"ttl={ttl} (<5)"
        ))

    return alerts


def build_dataset_row(pkt, flow=None, alert_names=None):
    """
    Build one row for the live dataset.
    This is how the ML model sees the network traffic.
    """
    flags = pkt.get("flags", {})
    extra = pkt.get("extra", {})

    row = {
        # ── Identity ──
        "timestamp":  datetime.datetime.fromtimestamp(pkt["timestamp"]).strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
        "src_ip":     pkt["src_ip"],
        "dst_ip":     pkt["dst_ip"],
        "src_port":   pkt["sport"],
        "dst_port":   pkt["dport"],
        "protocol":   pkt["proto_name"],
        # ── Packet features ──
        "pkt_size":   pkt["size"],
        "ttl":        pkt.get("ttl", 0),
        # ── TCP flags (0/1) ──
        "flag_syn":   int(flags.get("SYN", False)),
        "flag_ack":   int(flags.get("ACK", False)),
        "flag_fin":   int(flags.get("FIN", False)),
        "flag_rst":   int(flags.get("RST", False)),
        "flag_psh":   int(flags.get("PSH", False)),
        "flag_urg":   int(flags.get("URG", False)),
        # ── Port intelligence ──
        "dst_port_suspicious": int(pkt["dport"] in SUSPICIOUS_PORTS),
        "src_port_suspicious": int(pkt["sport"] in SUSPICIOUS_PORTS),
        "well_known_dst":      int(pkt["dport"] < 1024),
        # ── Flow features (if available) ──
        "flow_packets":  flow["packets"]   if flow else 1,
        "flow_bytes":    flow["bytes"]     if flow else pkt["size"],
        "flow_duration": round(flow["duration"], 4) if flow else 0,
        "flow_pkt_rate": round(flow["packets"] / max(flow["duration"], 0.001), 2) if flow else 0,
        "flow_byte_rate":round(flow["bytes"]   / max(flow["duration"], 0.001), 2) if flow else 0,
        "flow_syn_count":flow.get("syn_count",0) if flow else flags.get("SYN", 0),
        "flow_rst_count":flow.get("rst_count",0) if flow else flags.get("RST", 0),
        # ── ICMP ──
        "icmp_type":   extra.get("icmp_type", -1),
        # ── Label ──
        "alert":       ", ".join(alert_names) if alert_names else "NORMAL",
        "is_anomaly":  1 if alert_names else 0,
    }
    return row


# ── Per-second rate tracking ──────────────────────────────────────────────────
_rate_window = collections.deque(maxlen=60)  # last 60 seconds

def _rate_tracker():
    """Background thread: compute packets/sec and bytes/sec."""
    last_pkts  = 0
    last_bytes = 0
    while True:
        time.sleep(1)
        cur_pkts  = stats["total_packets"]
        cur_bytes = stats["total_bytes"]
        pps = cur_pkts - last_pkts
        bps = cur_bytes - last_bytes
        stats["packets_per_sec"] = pps
        stats["bytes_per_sec"]   = bps
        _rate_window.append({
            "t":   datetime.datetime.now().strftime("%H:%M:%S"),
            "pps": pps,
            "bps": bps,
        })
        last_pkts  = cur_pkts
        last_bytes = cur_bytes
        # Reset port scan trackers older than 30 seconds
        now = time.time()
        with scan_lock:
            dead = [ip for ip, t in port_scan_tracker.items() if now - t["last_seen"] > 30]
            for ip in dead:
                del port_scan_tracker[ip]


# ── Main capture loop ─────────────────────────────────────────────────────────

_running = False
_capture_thread = None


def _capture_loop():
    """Real AF_PACKET raw socket capture loop."""
    global _running
    try:
        sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(3))
        sock.settimeout(1.0)
    except PermissionError:
        # Fall back to simulation if no root access
        _simulate_loop()
        return

    while _running:
        try:
            raw, addr = sock.recvfrom(65535)
        except socket.timeout:
            continue
        except Exception:
            time.sleep(0.1)
            continue

        ip_data = parse_ethernet_frame(raw)
        if not ip_data:
            continue
        ip = parse_ip_header(ip_data)
        if not ip:
            continue

        sport, dport, flags, extra = parse_transport(ip["proto"], ip["payload"])
        now = time.time()

        pkt = {
            "timestamp":  now,
            "src_ip":     ip["src_ip"],
            "dst_ip":     ip["dst_ip"],
            "sport":      sport,
            "dport":      dport,
            "proto":      ip["proto"],
            "proto_name": protocol_map.get(ip["proto"], str(ip["proto"])),
            "size":       ip["total_len"],
            "ttl":        ip["ttl"],
            "flags":      flags,
            "extra":      extra,
            "time_str":   datetime.datetime.fromtimestamp(now).strftime("%H:%M:%S.%f")[:-3],
        }

        # Update counters
        stats["total_packets"] += 1
        stats["total_bytes"]   += pkt["size"]
        pname = pkt["proto_name"]
        if pname == "TCP":   stats["tcp_count"]   += 1
        elif pname == "UDP": stats["udp_count"]   += 1
        elif pname == "ICMP":stats["icmp_count"]  += 1
        else:                stats["other_count"] += 1

        # Update flow
        completed_flow = update_flow(pkt)

        # Threat detection
        alerts = detect_threats(pkt, completed_flow)
        alert_names = [a["name"] for a in alerts]

        for a in alerts:
            stats["alerts"] += 1
            try:
                alert_queue.put_nowait(a)
            except queue.Full:
                pass

        # Build dataset row
        row = build_dataset_row(pkt, completed_flow, alert_names if alert_names else None)
        dataset_rows.append(row)

        # Push to packet queue for live feed
        try:
            packet_queue.put_nowait(pkt)
        except queue.Full:
            pass

    sock.close()


# ── Simulation mode (fallback / always-on for realistic demo) ─────────────────

SIMULATED_PROFILES = [
    # (weight, src_range, dst_range, proto, dport_range, pkt_size_range, label, flags_template)
    (40, "192.168.1", "10.0.0",  6,  [80, 443, 22, 8080], (40, 1500),  "normal",  {"SYN":False,"ACK":True}),
    (20, "10.0.0",   "192.168.1",6,  [80, 443],            (200, 1400), "normal",  {"ACK":True,"PSH":True}),
    (10, "192.168.1","8.8.8.8",  17, [53, 123],            (60, 200),   "normal",  {}),
    (5,  "172.16.0", "192.168.1",6,  [445, 139, 135],      (80, 400),   "suspicious",{"SYN":True}),
    (3,  "10.10.0",  "192.168.1",6,  list(range(1,1025)),  (40, 80),    "scan",    {"SYN":True}),
    (5,  "192.168.1","192.168.2",1,  [0],                  (64, 1200),  "icmp",    {}),
    (3,  "172.31.0", "10.0.0",   6,  [4444,6667,31337],    (100, 600),  "malware", {"SYN":True,"PSH":True}),
    (2,  "10.0.0",   "172.16.0", 6,  [3389, 5900, 23],     (80, 300),   "rdp_vnc", {"SYN":True}),
    (2,  "192.168.5","10.0.0",   6,  [80],                 (40, 80),    "flood",   {"SYN":True}),
    (10, "192.168.1","10.0.0",   6,  [443, 80, 8443],      (200, 1460), "normal",  {"ACK":True}),
]

_weights = [p[0] for p in SIMULATED_PROFILES]
_weight_total = sum(_weights)

_scan_src = {}   # src -> list of ports already sent (for simulated scan tracking)


def _rand_ip(prefix):
    return f"{prefix}.{random.randint(1,254)}.{random.randint(1,254)}"


def _simulate_loop():
    """Simulate realistic mixed network traffic including attack patterns."""
    global _running
    sim_counter = 0
    while _running:
        # Variable speed: burst every ~50ms
        count = random.randint(2, 8)
        for _ in range(count):
            r = random.random() * _weight_total
            cumul = 0
            profile = SIMULATED_PROFILES[0]
            for p in SIMULATED_PROFILES:
                cumul += p[0]
                if r <= cumul:
                    profile = p
                    break

            _, src_pfx, dst_pfx, proto, dports, size_range, label, flags_tmpl = profile
            src_ip  = _rand_ip(src_pfx)
            dst_ip  = _rand_ip(dst_pfx) if isinstance(dst_pfx, str) else dst_pfx
            dport   = random.choice(dports) if dports else random.randint(1024, 65535)
            sport   = random.randint(1024, 65535)
            size    = random.randint(*size_range)
            ttl     = random.choice([32, 64, 64, 64, 128, 255])
            now     = time.time()

            flags = {}
            if proto == 6:
                flags = {
                    "SYN": flags_tmpl.get("SYN", False),
                    "ACK": flags_tmpl.get("ACK", False),
                    "FIN": flags_tmpl.get("FIN", False),
                    "RST": flags_tmpl.get("RST", random.random() < 0.01),
                    "PSH": flags_tmpl.get("PSH", False),
                    "URG": False,
                }
                # Occasionally make NULL or XMAS for demo
                if random.random() < 0.005:
                    flags = {k: False for k in flags}
                if random.random() < 0.005:
                    flags.update({"FIN": True, "URG": True, "PSH": True, "SYN": False})
                if label == "flood":
                    flags["SYN"] = True
                    flags["ACK"] = False

            extra = {}
            if proto == 1:
                extra = {"icmp_type": random.choice([0, 8, 8, 11, 3]), "icmp_code": 0}
                # Occasionally oversized ICMP
                if random.random() < 0.05:
                    size = random.randint(1100, 2000)

            if proto == 6 and label == "flood":
                ttl = random.choice([1, 2, 3, 60, 64])

            pkt = {
                "timestamp":  now,
                "src_ip":     src_ip,
                "dst_ip":     dst_ip,
                "sport":      sport,
                "dport":      dport,
                "proto":      proto,
                "proto_name": protocol_map.get(proto, str(proto)),
                "size":       size,
                "ttl":        ttl,
                "flags":      flags,
                "extra":      extra,
                "time_str":   datetime.datetime.fromtimestamp(now).strftime("%H:%M:%S.%f")[:-3],
                "simulated":  True,
            }

            # Update counters
            stats["total_packets"] += 1
            stats["total_bytes"]   += size
            pname = pkt["proto_name"]
            if pname == "TCP":    stats["tcp_count"]  += 1
            elif pname == "UDP":  stats["udp_count"]  += 1
            elif pname == "ICMP": stats["icmp_count"] += 1
            else:                 stats["other_count"]+= 1

            # Track flows
            completed_flow = update_flow(pkt)

            # Threat detection
            alerts = detect_threats(pkt, completed_flow)
            alert_names = [a["name"] for a in alerts]

            for a in alerts:
                stats["alerts"] += 1
                try:
                    alert_queue.put_nowait(a)
                except queue.Full:
                    pass

            row = build_dataset_row(pkt, completed_flow, alert_names if alert_names else None)
            dataset_rows.append(row)

            try:
                packet_queue.put_nowait(pkt)
            except queue.Full:
                pass

        time.sleep(0.05 + random.random() * 0.1)


def start():
    """Start capture + simulation + rate tracker threads."""
    global _running, _capture_thread
    if _running:
        return
    _running = True

    # Always run simulation for rich data, and try real capture in parallel
    sim_thread = threading.Thread(target=_simulate_loop, daemon=True, name="SimCapture")
    sim_thread.start()

    # Try real capture too
    real_thread = threading.Thread(target=_capture_loop, daemon=True, name="RealCapture")
    real_thread.start()

    rate_thread = threading.Thread(target=_rate_tracker, daemon=True, name="RateTracker")
    rate_thread.start()


def get_rate_history():
    return list(_rate_window)


def get_recent_packets(n=50):
    with packet_queue.mutex:
        items = list(packet_queue.queue)
    return items[-n:]


def get_recent_alerts(n=50):
    with alert_queue.mutex:
        items = list(alert_queue.queue)
    return items[-n:]


def get_dataset_preview(n=100):
    return list(dataset_rows)[-n:]


def get_stats():
    uptime = int(time.time() - stats["start_time"])
    return {**stats, "uptime_sec": uptime}
