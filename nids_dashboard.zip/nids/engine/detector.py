"""
engine/detector.py
───────────────────
ML-based intrusion detection engine.

Models:
  1. Random Forest Classifier  — supervised, trained on labelled NSL-KDD-style features
                                  → predicts: Normal / DoS / Probe / R2L / U2R
  2. Isolation Forest          — unsupervised anomaly detector
                                  → flags flows that deviate from the normal baseline

Feature pipeline:
  - 22 numeric features from each flow record
  - Protocol / service / flag one-hot encoded
  - StandardScaler normalisation

Training:
  - Called once at startup using generate_historical() data
  - Retrains automatically every 500 live records
"""

import numpy as np
import threading
import time
import json
import os
import datetime
from collections import defaultdict, deque

from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ── Feature columns used for ML ──────────────────────────────────────────────
NUMERIC_FEATURES = [
    "duration", "src_bytes", "dst_bytes", "land", "wrong_fragment",
    "urgent", "hot", "num_failed_logins", "logged_in", "num_compromised",
    "count", "srv_count", "serror_rate", "rerror_rate",
    "same_srv_rate", "diff_srv_rate", "dst_host_count",
    "dst_host_srv_count", "dst_host_diff_srv_rate", "dst_host_serror_rate",
    "src_bytes_log",   # engineered: log1p(src_bytes)
    "dst_bytes_log",   # engineered: log1p(dst_bytes)
]

LABEL_CLASSES = ["Normal", "DoS", "Probe", "R2L", "U2R"]


def _extract_features(record):
    """Convert a flow record dict → flat numeric feature vector."""
    row = []
    for f in NUMERIC_FEATURES:
        if f == "src_bytes_log":
            row.append(float(np.log1p(record.get("src_bytes", 0))))
        elif f == "dst_bytes_log":
            row.append(float(np.log1p(record.get("dst_bytes", 0))))
        else:
            row.append(float(record.get(f, 0)))
    return row


def _records_to_Xy(records):
    X = np.array([_extract_features(r) for r in records], dtype=np.float32)
    y = np.array([r["label"] for r in records])
    return X, y


class NIDSDetector:
    """
    Core detection engine. Holds two models and a live event store.
    Thread-safe — all model access is protected by a lock.
    """

    def __init__(self):
        self._lock       = threading.Lock()
        self._rf         = None          # Random Forest
        self._iso        = None          # Isolation Forest
        self._scaler     = StandardScaler()
        self._trained    = False
        self._train_size = 0
        self._rf_accuracy   = 0.0
        self._rf_report     = {}
        self._confusion     = []
        self._feature_imp   = {}
        self._records_since_retrain = 0
        self._retrain_interval = 500

        # Live event store (deque for memory efficiency)
        self._live_records    = deque(maxlen=5000)
        self._alert_log       = deque(maxlen=1000)
        self._stats_cache     = {}
        self._last_stats_time = 0

        # Per-IP state tracking (for rate-based detection)
        self._ip_counters = defaultdict(lambda: {"count": 0, "attacks": 0, "last_seen": None})

        # Counters for timeline
        self._minute_buckets  = defaultdict(lambda: defaultdict(int))

    # ── Training ─────────────────────────────────────────────────────────────

    def train(self, records):
        """Train / retrain both models on the given records list."""
        if len(records) < 100:
            return False

        X, y = _records_to_Xy(records)

        # Split 80/20
        n     = len(X)
        idx   = np.random.permutation(n)
        split = int(n * 0.8)
        X_tr, X_te = X[idx[:split]], X[idx[split:]]
        y_tr, y_te = y[idx[:split]], y[idx[split:]]

        # Fit scaler on training set
        scaler = StandardScaler()
        X_tr_s = scaler.fit_transform(X_tr)
        X_te_s = scaler.transform(X_te)

        # ── Random Forest ────────────────────────────────────────────────────
        rf = RandomForestClassifier(
            n_estimators=120, max_depth=18, min_samples_leaf=2,
            class_weight="balanced", n_jobs=-1, random_state=42)
        rf.fit(X_tr_s, y_tr)

        y_pred = rf.predict(X_te_s)
        acc    = accuracy_score(y_te, y_pred)
        report = classification_report(y_te, y_pred,
                                       output_dict=True, zero_division=0)

        # Feature importances
        feat_imp = {NUMERIC_FEATURES[i]: round(float(v), 4)
                    for i, v in enumerate(rf.feature_importances_)}
        feat_imp = dict(sorted(feat_imp.items(), key=lambda x: -x[1]))

        # Confusion matrix
        classes = sorted(set(y_te))
        cm = confusion_matrix(y_te, y_pred, labels=classes).tolist()

        # ── Isolation Forest (trained on normal only) ─────────────────────
        normal_idx = np.where(y_tr == "Normal")[0]
        X_normal   = X_tr_s[normal_idx]
        iso = IsolationForest(n_estimators=100, contamination=0.05,
                              random_state=42, n_jobs=-1)
        iso.fit(X_normal)

        # Atomically replace models
        with self._lock:
            self._rf        = rf
            self._iso       = iso
            self._scaler    = scaler
            self._trained   = True
            self._train_size = n
            self._rf_accuracy = round(acc * 100, 2)
            self._rf_report  = report
            self._confusion  = cm
            self._confusion_labels = classes
            self._feature_imp = feat_imp
            self._records_since_retrain = 0

        return True

    # ── Prediction ────────────────────────────────────────────────────────────

    def predict(self, record):
        """
        Classify a single flow record.
        Returns (rf_label, rf_confidence, anomaly_score, is_anomaly, reasons)
        """
        with self._lock:
            if not self._trained:
                return record.get("label","Normal"), 0.5, 0.0, False, ["Model not trained"]

            x = np.array([_extract_features(record)], dtype=np.float32)
            x_s = self._scaler.transform(x)

            # Random Forest prediction
            rf_proba = self._rf.predict_proba(x_s)[0]
            rf_classes = self._rf.classes_
            best_idx = int(np.argmax(rf_proba))
            rf_label = rf_classes[best_idx]
            rf_conf  = round(float(rf_proba[best_idx]), 4)

            # Isolation Forest anomaly score (-1 = anomaly, 1 = normal)
            iso_score = float(self._iso.decision_function(x_s)[0])
            is_anomaly = bool(self._iso.predict(x_s)[0] == -1)

            # Build human-readable reasons
            reasons = self._build_reasons(record, rf_label, iso_score, is_anomaly)

        return rf_label, rf_conf, iso_score, is_anomaly, reasons

    def _build_reasons(self, r, rf_label, iso_score, is_anomaly):
        """Return a list of plain-English detection reasons."""
        reasons = []

        if rf_label != "Normal":
            reasons.append(f"RF classifier detected: {rf_label}")

        if is_anomaly:
            reasons.append(f"Isolation Forest flagged as anomaly (score={iso_score:.3f})")

        # Rule-based heuristics (interpretable layer)
        if r.get("serror_rate", 0) > 0.8:
            reasons.append("High SYN error rate (>80%) — SYN flood indicator")
        if r.get("rerror_rate", 0) > 0.8:
            reasons.append("High REJ error rate (>80%) — port scan / UDP flood")
        if r.get("diff_srv_rate", 0) > 0.7:
            reasons.append("High diff-service rate (>70%) — horizontal scan")
        if r.get("num_failed_logins", 0) >= 3:
            reasons.append(f"Multiple failed logins ({r['num_failed_logins']}) — brute force")
        if r.get("num_compromised", 0) >= 3:
            reasons.append(f"Compromised indicators = {r['num_compromised']} — U2R / post-exploit")
        if r.get("hot", 0) >= 6:
            reasons.append(f"High 'hot' indicator = {r['hot']} — sensitive data access")
        if r.get("blacklisted_src", False):
            reasons.append("Source IP matches threat-intel blacklist")
        if r.get("urgent", 0) > 0:
            reasons.append("Urgent flag set — possible exploit payload")
        if r.get("wrong_fragment", 0) > 0:
            reasons.append("IP fragmentation anomaly — possible evasion")
        if r.get("count", 0) > 400 and r.get("same_srv_rate", 0) > 0.9:
            reasons.append("Very high connection count to same service — DoS signature")

        if not reasons:
            reasons.append("No anomalies detected — traffic appears normal")

        return reasons

    # ── Live record ingestion ────────────────────────────────────────────────

    def ingest(self, record):
        """
        Process one live record: run ML prediction, update stores, create alerts.
        Returns enriched record with prediction fields added.
        """
        rf_label, rf_conf, iso_score, is_anomaly, reasons = self.predict(record)

        # Enrich the record
        r = dict(record)
        r["rf_label"]    = rf_label
        r["rf_conf"]     = rf_conf
        r["iso_score"]   = round(iso_score, 4)
        r["is_anomaly"]  = is_anomaly
        r["reasons"]     = reasons
        r["final_label"] = rf_label if rf_label != "Normal" else ("Anomaly" if is_anomaly else "Normal")
        r["detected"]    = r["final_label"] != "Normal"

        # Update IP counters
        src = r.get("src_ip","")
        self._ip_counters[src]["count"]    += 1
        self._ip_counters[src]["last_seen"] = r["timestamp"]
        if r["detected"]:
            self._ip_counters[src]["attacks"] += 1

        # Bucket for timeline
        ts_str = r["timestamp"][:16]  # "YYYY-MM-DD HH:MM"
        self._minute_buckets[ts_str][r["final_label"]] += 1

        # Store
        self._live_records.append(r)
        self._records_since_retrain += 1

        # Create alert for non-normal
        if r["detected"]:
            self._alert_log.appendleft({
                "time":      r["timestamp"],
                "src_ip":    r["src_ip"],
                "dst_ip":    r["dst_ip"],
                "service":   r["service"],
                "label":     r["final_label"],
                "subtype":   r.get("subtype", r["final_label"]),
                "severity":  r.get("severity", "medium"),
                "score":     r.get("threat_score", 50),
                "conf":      rf_conf,
                "reasons":   reasons,
            })

        # Invalidate stats cache
        self._last_stats_time = 0

        return r

    def ingest_batch(self, records):
        return [self.ingest(r) for r in records]

    # ── Statistics for dashboard ──────────────────────────────────────────────

    def get_stats(self):
        """Return a comprehensive stats dict for the dashboard."""
        now = time.time()
        if now - self._last_stats_time < 0.5:
            return self._stats_cache

        recs = list(self._live_records)
        if not recs:
            return {"empty": True}

        total  = len(recs)
        labels = [r.get("final_label","Normal") for r in recs]

        label_counts = defaultdict(int)
        for l in labels:
            label_counts[l] += 1

        attack_recs = [r for r in recs if r.get("detected")]
        recent_100  = recs[-100:]
        recent_attacks = [r for r in recent_100 if r.get("detected")]

        # Protocol distribution
        proto_counts = defaultdict(int)
        svc_counts   = defaultdict(int)
        for r in recs:
            proto_counts[r.get("protocol","?")] += 1
            svc_counts[r.get("service","?")] += 1

        # Top attacker IPs
        ip_attack_counts = defaultdict(int)
        for r in attack_recs:
            ip_attack_counts[r.get("src_ip","?")] += 1
        top_attackers = sorted(ip_attack_counts.items(), key=lambda x: -x[1])[:10]

        # Timeline (last 60 minute buckets)
        now_dt = datetime.datetime.now()
        timeline = []
        for m in range(59, -1, -1):
            ts = (now_dt - datetime.timedelta(minutes=m)).strftime("%Y-%m-%d %H:%M")
            bucket = self._minute_buckets.get(ts, {})
            timeline.append({
                "time":   ts[-5:],  # "HH:MM"
                "Normal": bucket.get("Normal", 0),
                "DoS":    bucket.get("DoS", 0),
                "Probe":  bucket.get("Probe", 0),
                "R2L":    bucket.get("R2L", 0),
                "U2R":    bucket.get("U2R", 0),
                "Anomaly":bucket.get("Anomaly", 0),
            })

        # Threat score distribution (histogram 0-100 in 10 bins)
        scores = [r.get("threat_score", 0) for r in recs]
        hist_bins = [0]*10
        for s in scores:
            hist_bins[min(int(s//10), 9)] += 1

        # Feature averages (for "why" table)
        feature_avgs = {}
        for f in ["serror_rate","rerror_rate","diff_srv_rate",
                  "num_failed_logins","hot","count","src_bytes","dst_bytes"]:
            vals = [r.get(f,0) for r in recs]
            feature_avgs[f] = round(sum(vals)/len(vals), 3) if vals else 0

        with self._lock:
            trained    = self._trained
            accuracy   = self._rf_accuracy
            train_size = self._train_size
            feat_imp   = dict(self._feature_imp)
            cm         = list(self._confusion)
            cm_labels  = list(getattr(self, "_confusion_labels", []))

        stats = {
            "total":         total,
            "normal":        label_counts.get("Normal", 0),
            "dos":           label_counts.get("DoS", 0),
            "probe":         label_counts.get("Probe", 0),
            "r2l":           label_counts.get("R2L", 0),
            "u2r":           label_counts.get("U2R", 0),
            "anomaly":       label_counts.get("Anomaly", 0),
            "total_attacks": len(attack_recs),
            "attack_rate":   round(len(attack_recs)/max(total,1)*100, 1),
            "recent_attacks": len(recent_attacks),
            "label_counts":  dict(label_counts),
            "proto_counts":  dict(proto_counts),
            "svc_counts":    dict(sorted(svc_counts.items(), key=lambda x:-x[1])[:12]),
            "top_attackers": top_attackers,
            "timeline":      timeline,
            "threat_hist":   hist_bins,
            "feature_avgs":  feature_avgs,
            "model_trained": trained,
            "rf_accuracy":   accuracy,
            "train_size":    train_size,
            "feature_imp":   feat_imp,
            "confusion_matrix": cm,
            "confusion_labels": cm_labels,
            "alerts":        list(self._alert_log)[:50],
            "ip_counters":   dict(self._ip_counters),
        }
        self._stats_cache = stats
        self._last_stats_time = now
        return stats

    def get_recent_records(self, n=200):
        return list(self._live_records)[-n:]
