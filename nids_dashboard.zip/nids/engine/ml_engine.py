"""
ml_engine.py — Live machine learning anomaly detection.
Uses IsolationForest trained continuously on the live dataset.
Explains every prediction: what features triggered it, what it was compared to.
"""

import threading
import time
import math
import collections
import datetime
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import numpy as np

from engine.capture import dataset_rows, alert_queue, stats

# ── ML state ──────────────────────────────────────────────────────────────────
ml_state = {
    "model":         None,
    "scaler":        None,
    "trained":       False,
    "train_count":   0,
    "last_trained":  None,
    "anomalies_detected": 0,
    "predictions":   collections.deque(maxlen=500),
    "feature_names": [],
    "feature_importance": {},   # proxy importance via mean absolute deviation
    "training_stats": {},
    "status": "Waiting for data (need ≥ 50 samples)...",
}
ml_lock = threading.Lock()

# Features used for ML (must match dataset row keys)
FEATURES = [
    "pkt_size", "ttl", "flag_syn", "flag_ack", "flag_fin",
    "flag_rst", "flag_psh", "flag_urg",
    "dst_port_suspicious", "src_port_suspicious", "well_known_dst",
    "flow_packets", "flow_bytes", "flow_duration", "flow_pkt_rate",
    "flow_byte_rate", "flow_syn_count", "flow_rst_count",
    "icmp_type",
]

FEATURE_DESCRIPTIONS = {
    "pkt_size":            "Packet size (bytes) — abnormally large/small packets are suspicious",
    "ttl":                 "Time-To-Live — very low TTL may indicate evasion or traceroute",
    "flag_syn":            "TCP SYN flag — set when initiating connection",
    "flag_ack":            "TCP ACK flag — set in established connections",
    "flag_fin":            "TCP FIN flag — set when closing connection",
    "flag_rst":            "TCP RST flag — set to forcibly reset connection",
    "flag_psh":            "TCP PSH flag — push data immediately",
    "flag_urg":            "TCP URG flag — urgent data (rarely used legitimately)",
    "dst_port_suspicious": "Destination port is known-suspicious (Telnet/SMB/RDP/Meterpreter...)",
    "src_port_suspicious": "Source port is known-suspicious",
    "well_known_dst":      "Destination is a well-known port (<1024)",
    "flow_packets":        "Total packets in this network flow",
    "flow_bytes":          "Total bytes in this network flow",
    "flow_duration":       "How long the flow lasted (seconds)",
    "flow_pkt_rate":       "Packets per second in this flow",
    "flow_byte_rate":      "Bytes per second in this flow",
    "flow_syn_count":      "Number of SYN packets in flow (high = possible SYN flood)",
    "flow_rst_count":      "Number of RST packets in flow (high = possible scan/hijack)",
    "icmp_type":           "ICMP message type (8=echo request, 0=reply, 3=unreachable)",
}


def rows_to_matrix(rows):
    """Convert dataset rows to feature matrix."""
    X = []
    for r in rows:
        try:
            vec = [float(r.get(f, 0) or 0) for f in FEATURES]
            X.append(vec)
        except Exception:
            pass
    return np.array(X, dtype=np.float32) if X else np.zeros((0, len(FEATURES)), dtype=np.float32)


def compute_feature_importance(X_scaled, model):
    """
    Compute proxy feature importance:
    For anomalous samples, measure how far each feature deviates from normal mean.
    """
    if len(X_scaled) == 0:
        return {}
    scores = model.score_samples(X_scaled)
    normal_mask  = scores > np.percentile(scores, 25)
    anomaly_mask = scores < np.percentile(scores, 10)

    if normal_mask.sum() == 0 or anomaly_mask.sum() == 0:
        return {}

    normal_mean  = X_scaled[normal_mask].mean(axis=0)
    anomaly_mean = X_scaled[anomaly_mask].mean(axis=0)
    importance   = np.abs(anomaly_mean - normal_mean)

    return {FEATURES[i]: round(float(importance[i]), 4) for i in range(len(FEATURES))}


def explain_prediction(row, score, X_scaled_row, scaler_mean, scaler_std):
    """
    Explain why a sample was flagged as anomalous.
    Returns a list of {feature, value, normal_range, deviation, why} dicts.
    """
    explanations = []
    for i, fname in enumerate(FEATURES):
        raw_val    = float(row.get(fname, 0) or 0)
        scaled_val = float(X_scaled_row[i])
        mean       = float(scaler_mean[i])
        std        = float(scaler_std[i]) if scaler_std[i] > 0 else 1
        z_score    = abs(scaled_val)   # already z-scored by StandardScaler
        if z_score > 1.5:
            normal_low  = round(mean - std, 3)
            normal_high = round(mean + std, 3)
            explanations.append({
                "feature":      fname,
                "value":        round(raw_val, 4),
                "normal_range": f"{normal_low} – {normal_high}",
                "z_score":      round(z_score, 2),
                "why":          FEATURE_DESCRIPTIONS.get(fname, fname),
            })
    # Sort by most deviant first
    explanations.sort(key=lambda x: -x["z_score"])
    return explanations[:6]


def _train_loop():
    """Background thread: retrain model every 30 seconds on latest data."""
    while True:
        time.sleep(15)
        rows = list(dataset_rows)
        if len(rows) < 50:
            ml_state["status"] = f"Collecting data... ({len(rows)}/50 samples)"
            continue

        X = rows_to_matrix(rows)
        if X.shape[0] < 50:
            continue

        try:
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)

            model = IsolationForest(
                n_estimators=100,
                contamination=0.08,
                max_samples="auto",
                random_state=42,
                n_jobs=-1,
            )
            model.fit(X_scaled)

            importance = compute_feature_importance(X_scaled, model)

            # Compute training stats
            scores = model.score_samples(X_scaled)
            preds  = model.predict(X_scaled)
            n_anomalies = int((preds == -1).sum())

            with ml_lock:
                ml_state["model"]        = model
                ml_state["scaler"]       = scaler
                ml_state["trained"]      = True
                ml_state["train_count"] += 1
                ml_state["last_trained"] = datetime.datetime.now().strftime("%H:%M:%S")
                ml_state["feature_importance"] = importance
                ml_state["feature_names"]      = FEATURES
                ml_state["training_stats"] = {
                    "samples":         len(rows),
                    "anomalies_found": n_anomalies,
                    "anomaly_rate":    round(n_anomalies / len(rows) * 100, 1),
                    "score_mean":      round(float(scores.mean()), 4),
                    "score_std":       round(float(scores.std()), 4),
                    "score_min":       round(float(scores.min()), 4),
                    "score_max":       round(float(scores.max()), 4),
                    "threshold":       round(float(np.percentile(scores, 8)), 4),
                }
                ml_state["status"] = (
                    f"Model trained on {len(rows)} samples | "
                    f"{n_anomalies} anomalies ({ml_state['training_stats']['anomaly_rate']}%) | "
                    f"Last: {ml_state['last_trained']}"
                )

        except Exception as e:
            ml_state["status"] = f"Training error: {e}"


def _predict_loop():
    """Background thread: score new dataset rows as they arrive."""
    last_idx = 0
    while True:
        time.sleep(2)
        with ml_lock:
            if not ml_state["trained"]:
                continue
            model  = ml_state["model"]
            scaler = ml_state["scaler"]

        rows = list(dataset_rows)
        new_rows = rows[last_idx:]
        if not new_rows:
            continue
        last_idx = len(rows)

        X = rows_to_matrix(new_rows)
        if X.shape[0] == 0:
            continue

        try:
            X_scaled = scaler.transform(X)
            scores   = model.score_samples(X_scaled)
            preds    = model.predict(X_scaled)

            with ml_lock:
                threshold = ml_state["training_stats"].get("threshold", -0.5)
                scaler_mean = scaler.mean_
                scaler_std  = np.sqrt(scaler.var_)

                for i, (row, score, pred) in enumerate(zip(new_rows, scores, preds)):
                    is_anomaly = pred == -1
                    if is_anomaly:
                        ml_state["anomalies_detected"] += 1
                        explanations = explain_prediction(
                            row, score, X_scaled[i], scaler_mean, scaler_std)
                        prediction = {
                            "timestamp":   row.get("timestamp", ""),
                            "src_ip":      row.get("src_ip", ""),
                            "dst_ip":      row.get("dst_ip", ""),
                            "src_port":    row.get("src_port", 0),
                            "dst_port":    row.get("dst_port", 0),
                            "protocol":    row.get("protocol", ""),
                            "score":       round(float(score), 4),
                            "threshold":   round(threshold, 4),
                            "is_anomaly":  True,
                            "label":       row.get("alert", "UNKNOWN"),
                            "top_features":explanations,
                            "how_detected":(
                                "IsolationForest: This sample was isolated in fewer splits than normal "
                                f"(anomaly score={round(float(score),4)}, threshold={round(threshold,4)}). "
                                "The model built 100 random trees; anomalies are points that reach a "
                                "leaf node faster because they are far from the bulk of traffic."
                            ),
                            "compared_to": (
                                f"Compared against {ml_state['training_stats'].get('samples','?')} "
                                "packets/flows captured in this session. The model learned what "
                                "'normal' traffic looks like from the baseline and flags deviations."
                            ),
                        }
                        ml_state["predictions"].append(prediction)

                        # Also raise as alert
                        alert = {
                            "id":          f"ml-{int(time.time()*1000)}-{i}",
                            "timestamp":   row.get("timestamp", "")[-12:],
                            "name":        "ML Anomaly Detected",
                            "severity":    "HIGH" if score < threshold * 1.5 else "MEDIUM",
                            "description": (
                                f"IsolationForest flagged {row.get('src_ip','')} → "
                                f"{row.get('dst_ip','')}:{row.get('dst_port','')} as anomalous "
                                f"(score={round(float(score),4)})."
                            ),
                            "category":    "ML Detection",
                            "src_ip":      row.get("src_ip",""),
                            "dst_ip":      row.get("dst_ip",""),
                            "sport":       row.get("src_port",0),
                            "dport":       row.get("dst_port",0),
                            "proto":       row.get("protocol",""),
                            "evidence":    f"top_features={[e['feature'] for e in explanations[:3]]}",
                            "where_checked": "ML Engine → IsolationForest → Feature deviation analysis",
                        }
                        try:
                            alert_queue.put_nowait(alert)
                            stats["alerts"] += 1
                        except Exception:
                            pass

        except Exception:
            pass


def start():
    threading.Thread(target=_train_loop,   daemon=True, name="MLTrain").start()
    threading.Thread(target=_predict_loop, daemon=True, name="MLPredict").start()


def get_ml_state():
    with ml_lock:
        return {
            "trained":      ml_state["trained"],
            "train_count":  ml_state["train_count"],
            "last_trained": ml_state["last_trained"],
            "status":       ml_state["status"],
            "anomalies_detected": ml_state["anomalies_detected"],
            "feature_importance": dict(sorted(
                ml_state["feature_importance"].items(),
                key=lambda x: -x[1]
            )[:10]),
            "training_stats": ml_state["training_stats"],
            "recent_anomalies": list(ml_state["predictions"])[-20:],
            "feature_names":    FEATURES,
            "feature_descriptions": FEATURE_DESCRIPTIONS,
        }
