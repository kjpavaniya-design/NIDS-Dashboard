# 🛡 Network Intrusion Detection & Threat Analytics Dashboard

A **fully live, real-time** network intrusion detection system with a web dashboard.

---

## What It Does

| Feature | Details |
|---------|---------|
| 📡 Live Packet Capture | AF_PACKET raw socket — captures every IPv4 packet on the network interface |
| 🔄 Flow Assembly | Groups packets into bidirectional flows using 5-tuple keys |
| 🚨 Rule-Based Detection | 7 deterministic rules (SYN flood, port scan, XMAS/NULL scan, etc.) |
| 🤖 ML Anomaly Detection | IsolationForest — trained live on captured traffic, retrained every 15s |
| 🗃 Live Dataset | Every packet → structured feature row, exportable as CSV |
| 📊 Live Charts | Packet/byte rates, protocol distribution, alert trends, port heatmap, ML scores |
| 🔍 Pipeline Explanation | Full explanation of how every detection decision was made |

---

## How Detection Works

### Step 1 — Packet Capture
Raw AF_PACKET socket captures every frame at Layer 2.
Each packet is parsed: `src_ip, dst_ip, src_port, dst_port, protocol, TTL, TCP flags, size`.

### Step 2 — Flow Assembly
Packets are grouped into flows by `(src_ip, dst_ip, src_port, dst_port, proto)`.
Flows track: duration, total bytes, packet count, SYN/RST counts, flag set.

### Step 3 — Rule-Based Detection
7 rules run on every packet and completed flow:
- **SYN Flood**: `SYN_count > 50` without ACK → CRITICAL
- **Port Scan**: ≥15 distinct destination ports from same source → HIGH
- **Suspicious Port**: traffic to Telnet/SMB/RDP/Meterpreter ports → MEDIUM
- **Large ICMP**: ICMP > 1000 bytes (tunnel/DoS) → MEDIUM
- **TCP NULL Scan**: all flags = 0 → HIGH
- **TCP XMAS Scan**: FIN+URG+PSH flags → HIGH
- **Low TTL**: TTL < 5 (evasion) → MEDIUM

### Step 4 — ML Anomaly Detection
IsolationForest with 19 features:
- Packet features: size, TTL, all 6 TCP flags
- Port intelligence: suspicious port flags, well-known-port flag
- Flow features: packets, bytes, duration, pkt_rate, byte_rate, syn_count, rst_count
- ICMP type

Model retrains every 15 seconds. Each anomaly is explained by showing which features
deviated most from normal (z-score > 1.5).

### Step 5 — Dataset Construction
Every packet becomes a row with 25+ columns. Labels: `NORMAL` or alert name.
Downloadable as CSV at any time.

---

## Installation

```bash
pip install flask psutil scikit-learn numpy pandas
```

## Running

```bash
python app.py
```

Open browser: **http://localhost:5000**

> **Note**: Real packet capture requires `sudo` / root privileges.
> Without root, the system runs in simulation mode with realistic synthetic traffic
> (mixed normal + attack patterns) — all detection logic is identical.

```bash
sudo python app.py   # real capture from eth0
python app.py        # simulation mode (no root needed)
```

---

## Dashboard Tabs

| Tab | What you see |
|-----|-------------|
| 📊 Overview | Stats, protocol pie, alert breakdown, rate charts |
| 📡 Live Packets | Real-time packet table with flags, TTL, protocol |
| 🚨 Threat Alerts | All rule + ML alerts with full evidence and "where detected" |
| 🤖 ML Detection | Model status, feature importance, anomaly explanations |
| 🗃 Live Dataset | Growing dataset table, CSV export |
| 🔍 How It Works | Full pipeline explanation, dataset schema, active rules |

---

## File Structure

```
nids/
├── app.py                 # Flask server + SSE endpoint
├── engine/
│   ├── capture.py         # Packet capture, flow assembly, rule detection, dataset
│   └── ml_engine.py       # IsolationForest training + anomaly explanation
└── templates/
    └── index.html         # Full live dashboard
```
