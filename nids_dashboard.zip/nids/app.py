"""
app.py — Flask dashboard server with Server-Sent Events (SSE) for live streaming.
"""

import json
import time
import datetime
import collections
import threading
import io
import csv

from flask import Flask, Response, jsonify, render_template, stream_with_context

import engine.capture  as cap
import engine.ml_engine as ml

app = Flask(__name__)

# Start capture + ML engines at startup
cap.start()
ml.start()


# ── SSE helpers ───────────────────────────────────────────────────────────────

def sse_event(data, event=None):
    msg = ""
    if event:
        msg += f"event: {event}\n"
    msg += f"data: {json.dumps(data)}\n\n"
    return msg


# ── SSE Stream endpoint ───────────────────────────────────────────────────────

@app.route("/stream")
def stream():
    """
    Server-Sent Events endpoint.
    Pushes stats, packets, alerts, and ML updates every second.
    """
    def generate():
        last_alert_id  = None
        last_ml_anom   = 0
        tick = 0
        while True:
            # ── Every tick: stats ──────────────────────────────────────────
            yield sse_event(cap.get_stats(), "stats")

            # ── Every tick: latest packets ─────────────────────────────────
            pkts = cap.get_recent_packets(20)
            safe_pkts = []
            for p in pkts:
                safe_pkts.append({
                    "time":    p.get("time_str",""),
                    "src":     f"{p.get('src_ip','')}:{p.get('sport','')}",
                    "dst":     f"{p.get('dst_ip','')}:{p.get('dport','')}",
                    "proto":   p.get("proto_name",""),
                    "size":    p.get("size",0),
                    "ttl":     p.get("ttl",0),
                    "flags":   ",".join(k for k,v in p.get("flags",{}).items() if v),
                    "sim":     p.get("simulated",False),
                })
            yield sse_event(safe_pkts, "packets")

            # ── Every tick: alerts ─────────────────────────────────────────
            alerts = cap.get_recent_alerts(30)
            yield sse_event(alerts, "alerts")

            # ── Every tick: rate history ───────────────────────────────────
            yield sse_event(cap.get_rate_history(), "rates")

            # ── Every 3 ticks: ML state ────────────────────────────────────
            if tick % 3 == 0:
                yield sse_event(ml.get_ml_state(), "ml")

            # ── Every 5 ticks: dataset preview ────────────────────────────
            if tick % 5 == 0:
                rows = cap.get_dataset_preview(50)
                yield sse_event(rows, "dataset")

            tick += 1
            time.sleep(1)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control":    "no-cache",
            "X-Accel-Buffering":"no",
            "Connection":       "keep-alive",
        }
    )


# ── REST API endpoints ────────────────────────────────────────────────────────

@app.route("/api/stats")
def api_stats():
    return jsonify(cap.get_stats())


@app.route("/api/alerts")
def api_alerts():
    return jsonify(cap.get_recent_alerts(100))


@app.route("/api/ml")
def api_ml():
    return jsonify(ml.get_ml_state())


@app.route("/api/dataset")
def api_dataset():
    rows = cap.get_dataset_preview(200)
    return jsonify({"rows": rows, "total": len(cap.dataset_rows)})


@app.route("/api/dataset/csv")
def api_dataset_csv():
    """Download the live dataset as CSV."""
    rows = list(cap.dataset_rows)
    if not rows:
        return "No data yet", 204
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    return Response(
        buf.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=live_dataset.csv"}
    )


@app.route("/api/how_it_works")
def api_how_it_works():
    """Return a full explanation of the detection pipeline."""
    return jsonify({
        "pipeline": [
            {
                "step": 1,
                "name": "Packet Capture",
                "where": "Network interface (eth0) via AF_PACKET raw socket",
                "what":  "Every IPv4 packet traversing the network interface is captured at Layer 2 (Ethernet frame level). No packets are missed — this is promiscuous capture.",
                "data_extracted": ["src_ip", "dst_ip", "src_port", "dst_port", "protocol", "TTL", "TCP flags", "packet size", "ICMP type/code"],
            },
            {
                "step": 2,
                "name": "Flow Assembly",
                "where": "In-memory flow table (5-tuple key)",
                "what":  "Individual packets are grouped into bidirectional flows using the 5-tuple: (src_ip, dst_ip, src_port, dst_port, protocol). Flows track aggregate statistics: total bytes, packet count, duration, flag counts. Flows are closed on RST/FIN or after 120s timeout.",
                "data_extracted": ["flow_duration", "flow_packets", "flow_bytes", "flow_pkt_rate", "flow_byte_rate", "syn_count", "rst_count"],
            },
            {
                "step": 3,
                "name": "Rule-Based Detection",
                "where": "Threat detection engine (7 rules)",
                "what":  "Each packet and completed flow is checked against deterministic rules derived from known attack patterns.",
                "rules": [
                    "SYN Flood: >50 SYN packets in a flow without ACK responses",
                    "Port Scan: same source probes ≥15 distinct destination ports",
                    "Suspicious Port: traffic to Telnet/SMB/RDP/Meterpreter/IRC ports",
                    "Large ICMP: >1000 byte ICMP (possible tunnel or smurf)",
                    "TCP NULL Scan: TCP packet with zero flags (stealth probe)",
                    "TCP XMAS Scan: FIN+URG+PSH flags (stealth probe)",
                    "Low TTL: TTL<5 (evasion or traceroute)",
                ],
            },
            {
                "step": 4,
                "name": "ML Anomaly Detection",
                "where": "IsolationForest model (sklearn) trained on live data",
                "what":  "IsolationForest builds 100 random decision trees. It isolates anomalies by splitting features randomly — anomalous points reach a leaf node in fewer splits because they lie far from the dense normal region. The model is retrained every 15 seconds on the growing live dataset.",
                "features_used": ml.FEATURES,
                "how_training_works": "1) Collect ≥50 packets from the live capture. 2) Normalise features with StandardScaler (zero mean, unit variance). 3) Fit IsolationForest with contamination=8% (expected 8% anomalous traffic). 4) Score every new packet: score < threshold → anomaly. 5) Explain each anomaly by finding features with z-score >1.5.",
            },
            {
                "step": 5,
                "name": "Dataset Construction",
                "where": "In-memory rolling dataset (last 2000 rows)",
                "what":  "Every packet/flow is turned into a structured feature row with 25+ columns. The dataset grows live and can be exported as CSV. The label column shows 'NORMAL' or the alert name(s) that fired for that packet.",
                "columns": ml.FEATURES + ["timestamp", "src_ip", "dst_ip", "src_port", "dst_port", "protocol", "alert", "is_anomaly"],
            },
        ]
    })


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
